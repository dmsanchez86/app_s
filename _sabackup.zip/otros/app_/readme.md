base de desarrolo de software


Referencias:


http://www.phpactiverecord.org/projects/main/wiki/Configuration__Setup
http://www.slimframework.com/