<?php
header('Access-Control-Allow-Origin: *');  
define('DS', DIRECTORY_SEPARATOR);
define('ROOT', dirname(__FILE__));

require_once (ROOT . DS . 'library' . DS . 'bootstrap.php');

$tpl = new RainTPL();

?>