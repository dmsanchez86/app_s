<?php

define ('DEVELOPMENT_ENVIRONMENT',true);
define('DB_CONECTION_TYPE', 'mongoDb');


define('TEMPLATE_PATH', '../templates');


/*define('DB_NAME', 'yourdatabasename');
define('DB_USER', 'yourusername');
define('DB_PASSWORD', 'yourpassword');
define('DB_HOST', 'localhost');*/