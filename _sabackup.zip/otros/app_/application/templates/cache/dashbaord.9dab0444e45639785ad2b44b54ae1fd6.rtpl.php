<?php if(!class_exists('raintpl')){exit;}?>sadasdasdasdasdas
d
as
d
