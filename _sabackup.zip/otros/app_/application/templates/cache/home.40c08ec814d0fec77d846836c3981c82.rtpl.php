<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html>
<head>
	<title> Gestionalo </title>
	<link rel="stylesheet" type="text/css" href="http://<?php echo $data["url_path"];?>css/styles.css">

	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

	<link href="http://<?php echo $data["url_path"];?>css/jquery.circliful.css" rel="stylesheet" type="text/css" />
	<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
	<script src="http://<?php echo $data["url_path"];?>js/jquery.circliful.min.js"></script>
	<script src="http://<?php echo $data["url_path"];?>js/script.js"></script>

</head>
<style type="text/css">

.zopp-chat{
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	padding: 0px;
	border: 0px;
	overflow: hidden;
	position: fixed;
	z-index: 16000002;
	width: 206px;
	height: 30px;
	right: 10px;
	bottom: 0px;
}

.col-md-2, .col-md-10{
    padding:0;
}
.panel{
    margin-bottom: 0px;
}
.chat-window{
    bottom:0;
    position:fixed;
    float:right;
    margin-left:10px;
}
.chat-window > div > .panel{
    border-radius: 5px 5px 0 0;
}
.icon_minim{
    padding:2px 10px;
}
.msg_container_base{
  background: #e5e5e5;
  margin: 0;
  padding: 0 10px 10px;
  max-height:300px;
  overflow-x:hidden;
}
.top-bar {
  background: #666;
  color: white;
  padding: 10px;
  position: relative;
  overflow: hidden;
}
.msg_receive{
    padding-left:0;
    margin-left:0;
}
.msg_sent{
    padding-bottom:20px !important;
    margin-right:0;
}
.messages {
  background: white;
  padding: 10px;
  border-radius: 2px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  max-width:100%;
}
.messages > p {
    font-size: 13px;
    margin: 0 0 0.2rem 0;
  }
.messages > time {
    font-size: 11px;
    color: #ccc;
}
.msg_container {
    padding: 10px;
    overflow: hidden;
    display: flex;
}
img {
    display: block;
    width: 100%;
}
.avatar {
    position: relative;
}
.base_receive > .avatar:after {
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    width: 0;
    height: 0;
    border: 5px solid #FFF;
    border-left-color: rgba(0, 0, 0, 0);
    border-bottom-color: rgba(0, 0, 0, 0);
}

.base_sent {
  justify-content: flex-end;
  align-items: flex-end;
}
.base_sent > .avatar:after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 0;
    border: 5px solid white;
    border-right-color: transparent;
    border-top-color: transparent;
    box-shadow: 1px 1px 2px rgba(black, 0.2); // not quite perfect but close
}

.msg_sent > time{
    float: right;
}



.msg_container_base::-webkit-scrollbar-track
{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    background-color: #F5F5F5;
}

.msg_container_base::-webkit-scrollbar
{
    width: 12px;
    background-color: #F5F5F5;
}

.msg_container_base::-webkit-scrollbar-thumb
{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
    background-color: #555;
}

.btn-group.dropup{
    position:fixed;
    left:0px;
    bottom:0;
}
</style>
<body>
<div class="zopp-chat">
<div class="container">
   <div class="row chat-window col-xs-5 col-md-3" id="chat_window_1" style="margin-left:10px;">
      <div class="col-xs-12 col-md-12">
         <div class="panel panel-default">
            <div class="panel-heading top-bar">
               <div class="col-md-8 col-xs-8">
                  <h3 class="panel-title"><span class="glyphicon glyphicon-comment"></span> Chat - Miguel</h3>
               </div>
               <div class="col-md-4 col-xs-4" style="text-align: right;">
                  <a href="#"><span id="minim_chat_window" class="glyphicon glyphicon-minus icon_minim"></span></a>
                  <a href="#"><span class="glyphicon glyphicon-remove icon_close" data-id="chat_window_1"></span></a>
               </div>
            </div>
            <div class="panel-body msg_container_base">
            </div>
            <div class="panel-footer">
               <div class="input-group">
                  <input id="btn-input" type="text" class="form-control input-sm chat_input" placeholder="Write your message here..." />
                  <span class="input-group-btn">
                  <button class="btn btn-primary btn-sm" id="btn-chat">Send</button>
                  </span>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="btn-group dropup">
      <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
      <span class="glyphicon glyphicon-cog"></span>
      <span class="sr-only">Toggle Dropdown</span>
      </button>
      <ul class="dropdown-menu" role="menu">
         <li><a href="#" id="new_chat"><span class="glyphicon glyphicon-plus"></span> Novo</a></li>
         <li><a href="#"><span class="glyphicon glyphicon-list"></span> Ver outras</a></li>
         <li><a href="#"><span class="glyphicon glyphicon-remove"></span> Fechar Tudo</a></li>
         <li class="divider"></li>
         <li><a href="#"><span class="glyphicon glyphicon-eye-close"></span> Invisivel</a></li>
      </ul>
   </div>
</div>
</div>
	<div>
		<div class="main">
			<div>
				<div class="container-left">
					<header class="container-logotype">
						<div class="container-logotype-2">
							<img src="http://<?php echo $data["url_path"];?>img/agencia web.png" class="logotype">
						</div>
					</header>

					<div class="container-blue"> 

						<div class="container-avatar">
							<div class="avatar-img">
								<div class="editar"><a href="">editar</a></div>
								<div class="img-avatar">
									<img src="http://<?php echo $data["url_path"];?>img/oscar.png" class="profile-img">
								</div>
							</div>
							<div class="avatar-name"> 
								<h3 class="name"> Oscar David</h3>
								<h4 class="profesion"> Director de empatia</h4>
							</div>
						</div>

						<div class="container-icon">
							<div class="icon a">
								<p> 23</p> <a href="#"><i class="fa fa-list-ul"></i> </a>
							</div>
							<div class="icon b">
								<p> 13</p> <a href="#"><i class="fa fa-calendar"></i> </a>
							</div>
							<div class="icon c">
								<p> 196</p> <a href=""><i class="fa fa-list-ul"></i> </a>
							</div>
							<div class="icon d">
								<p> 375</p> <a href=""><i class="fa fa-bullhorn"></i> </a>
							</div>
							<div class="icon e">
								<p> 34</p> <a href=""><i class="fa fa-list-ul"></i> </a>
							</div>
						</div>

						<div class="container-search">
							<input type="text" class="search" placeholder="Buscar plan..."><i class="fa fa-search"></i>
						</div>

						<div class="container-planes">
							<div class="menu">
								<a href=""><i class="fa fa-rocket"></i> <strong class="title-work">PLANES</strong></a>
								<ul class="menu-list">
									<li> <i class="fa fa-circle"></i> PLAN NUMERO UNO </li>
									<li><i class="fa fa-circle"></i> PLAN NUMERO DOS </li>
									<li><i class="fa fa-circle"></i> PLAN NUMERO TRES</li>
									<li><i class="fa fa-circle"></i> PLAN NUMERO CUATRO</li>
									<li><i class="fa fa-circle"></i> PLAN NUMERO CINCO</li>
									<li><i class="fa fa-circle"></i> PLAN NUMERO SEIS</li>
									<li><i class="fa fa-circle"></i> PLAN NUMERO SIETE</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="container-rigth">
					<div class="general-notifications"> Zona de notificaciones </div>
					<div class="container-all"> 
						<div class="member"> 
							<h3 class="title-members"> Miembros del plan</h3>
							<div class="profile">
								<div class="photo-friend"><a href="">Juan </a></div>
								<div class="conectado"><a href=""></a></div>
								<div class="photo-profile"> <img src="http://<?php echo $data["url_path"];?>img/1.png" class="profile-member"></div>
							</div>

							<div class="profile">
								<div class="photo-friend"><a href="">Juan </a></div>
								<div class="conectado"><a href=""></a></div>
								<div class="photo-profile"> <img src="http://<?php echo $data["url_path"];?>img/2.png" class="profile-member"></div>
							</div>

							<div class="profile">
								<div class="photo-friend"><a href="">Juan </a></div>
								<div class="conectado"><a href=""></a></div>
								<div class="photo-profile"> <img src="http://<?php echo $data["url_path"];?>img/3.png" class="profile-member"></div>
							</div>

							<div class="profile">
								<div class="photo-friend"><a href="">Juan </a></div>
								<div class="conectado"><a href=""></a></div>
								<div class="photo-profile"> <img src="http://<?php echo $data["url_path"];?>img/4.png" class="profile-member"></div>
							</div>

							<div class="profile">
								<div class="photo-friend"><a href="">Juan </a></div>
								<div class="conectado"><a href=""></a></div>
								<div class="photo-profile"> <img src="http://<?php echo $data["url_path"];?>img/5.png" class="profile-member"></div>
							</div>

							<div class="profile">
								<div class="photo-friend"><a href="">Juan </a></div>
								<div class="conectado"><a href=""></a></div>
								<div class="photo-profile"> <img src="http://<?php echo $data["url_path"];?>/img/6.png" class="profile-member"></div>
							</div>

						</div>
						<div> 
							<div class="workspace status">
								<h3 class="title-workspace">Estado del plan</h3>

								<div class="date"> 
									<div class="date-begin"> <h4 class="date-text">Fecha Inicio</h4> <h5>Enero 28 de 2015</h5></div>
									<div class="date-final"><h4 class="date-text">Fecha Inicio</h4> <h5>Enero 28 de 2015</h5></div>
								</div>
								<div id="myStat2" data-dimension="200" data-text="45%" data-info="75 dias restantes" data-width="30" data-fontsize="38" data-percent="45" data-fgcolor="#fff" data-bgcolor="#2969b0" class="circliful"></div>

								<div class="container-progress">
									<div class="divs">
										<div class="punto atrazado"></div>
										<div class="letrapunto">Atrasado</div>
									</div>

									<div class="divs">
										<div class="punto aldia"></div>
										<div class="letrapunto">Al d&iacute;a</div>
									</div>
									<div class="divs">
										<div class="punto adelantado"></div>
										<div class="letrapunto">Adelantado</div>
									</div>
								</div>
							</div>

							<div class="workspace task">
								<h3 class="title-workspace">
									<i class="fa fa-list-ul icon-menu"></i>
									Tareas
								</h3>
								<div>
									<div class="title-today">hoy</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
								</div>
								<div>
									<div class="title-today">Enero 16 de 2015</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
								</div>
								<div>
									<div class="title-today">Enero 5 de 2015</div>
									<div><i class="fa fa-circle"></i>tarea asignada numero UNO</div>
								</div>
							</div>
							<div class="workspace events">
								<h3 class="title-workspace"> 
									<i class="fa fa-calendar icon-menu"></i>
									Eventos
								</h3>
								<div>
									<div class="date-events"> 
										<span>17 <br>Sab</span>
									</div>
									<div class="name-events"> 
										<div> evento uno</div>
										<div> evento uno</div>
										<div> evento uno</div>
										<div> evento uno</div>
									</div>	
								
								
								</div>
							</div>
							<div class="workspace file">
								<h3 class="title-workspace">
									Archivos
								</h3>
								<div></div>
							</div>
						</div>
					</div>

					<div class="container-input">
						<div class="zone-comment">
							<p class="plan-selected">PLAN NUMERO DOS</p>
						</div>
						<div class="zone-comment">
						<input type="text" name="comment" class="comment">
						</div>
						<div class="zone-comment">
							icon
						</div>
					</div>


				</div>


			</div>
		</div>
	</div>
</body>
<script>
	$( document ).ready(function() {
		$('#myStat2').circliful();
	});
</script>

</html>