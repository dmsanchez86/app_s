<?php

namespace GitList\Exception;

class EmptyRepositoryException extends \RuntimeException
{
    
}
