<?php

/* footer.twig */
class __TwigTemplate_c7660cd4d62e47c739ea368bff19b4167e738bb575ad416cb054309be324145e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<footer>
    <p>Powered by <a href=\"https://github.com/klaussilveira/gitlist\">GitList 0.4.0</a></p>
</footer>
";
    }

    public function getTemplateName()
    {
        return "footer.twig";
    }

    public function getDebugInfo()
    {
        return array (  36 => 13,  19 => 1,  145 => 14,  139 => 5,  127 => 23,  119 => 22,  111 => 21,  79 => 17,  71 => 16,  62 => 15,  60 => 14,  48 => 9,  39 => 7,  31 => 6,  27 => 5,  21 => 1,  103 => 20,  101 => 32,  95 => 19,  87 => 18,  83 => 23,  76 => 21,  73 => 20,  66 => 17,  58 => 16,  54 => 14,  49 => 13,  40 => 6,  38 => 5,  35 => 4,  29 => 9,);
    }
}
